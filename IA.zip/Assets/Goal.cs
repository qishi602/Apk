using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    public GameObject TaxiWinS;
    public GameObject CarWinS;
    public GameObject TaxiWinM;
    public GameObject CarWinM;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == TaxiWinM)
        {
            TaxiWinS.SetActive(true);
        }
        if (other.gameObject == CarWinM)
        {
            CarWinS.SetActive(true);
        }
    }
}
