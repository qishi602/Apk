using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class Car : MonoBehaviour
{
    public GameObject CarObj;
    public GameObject GoalObj;
    public GameObject WinScreenS;
    private bool hasWon = false;
    public MonoBehaviour Stop;
    void Start()
    {
        GetComponent<VirtualButtonBehaviour>().RegisterOnButtonPressed(OnButtonPressed);
    }
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        if (hasWon) return;
        CarObj.transform.Translate(Vector3.forward * 0.1f);
        CheckWinCondition();
    }
    void CheckWinCondition()
    {
        if (GoalObj == null || WinScreenS == null) return;
        float distance = Vector3.Distance(CarObj.transform.position, GoalObj.transform.position);
        if (distance <= 0.1)
        {
            hasWon = true;
            WinScreenS.SetActive(true);
            Stop.enabled = false;
        }
    }
}
