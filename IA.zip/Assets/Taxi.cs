using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class Taxi : MonoBehaviour
{
    public GameObject TaxiObj;
    public GameObject GoalObj;
    public GameObject WinScreenS;
    private bool hasWon = false;
    public MonoBehaviour Stop;
    void Start()
    {
        GetComponent<VirtualButtonBehaviour>().RegisterOnButtonPressed(OnButtonPressed);
    }
    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        if (hasWon) return;
        TaxiObj.transform.Translate(Vector3.forward * 0.1f);
        CheckWinCondition();
    }
    void CheckWinCondition()
    {
        if (GoalObj == null || WinScreenS == null) return;
        float distance = Vector3.Distance(TaxiObj.transform.position, GoalObj.transform.position);
        if (distance <= 0.1)
        {
            hasWon = true;
            WinScreenS.SetActive(true);
            Stop.enabled = false;
        }
    }
}